Jeg prøvde så godt jeg kunne å gjøre oppgaven i Java, men fant fort ut av at det vi har lært på skolen angående Java er bare bruk av verdier og tekstformler.
Så har dessverre besvart oppgaven i Javascript / HTML med bruk av localStorage

Så vi har ikke lært noe mer angående java en bruk av scanner, og nettet var ikke til stor hjelp.
Jeg fikk til å lære hvordan jeg startet et nytt prosjekt og bruk av Play Framework, men må jobbe mer med dette.
Greide heller ikke å integrere MySQL i oppgaven, derfor ble MyCounter lagret i localStorage.

For å kjøre --> cmd --> cd counter-test --> sbt run --> skal kjøpre på localhost:9000