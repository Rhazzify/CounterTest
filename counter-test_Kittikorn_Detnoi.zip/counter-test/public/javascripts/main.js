

//let counterDeserialized = JSON.parse(localStorage.getItem("MyCounter"));
let counter = document.getElementById("counterNumber");

let counterNumber = 0;


function onClickIncrement(){
    counterNumber += 1;
    counter.innerHTML = counterNumber;

    let counterSerialized = JSON.stringify(counterNumber);

    localStorage.setItem("MyCounter", counterSerialized);

    let counterDeserialized = JSON.parse(localStorage.getItem("MyCounter"));

    console.log(counterDeserialized)
}

function onClickDecrement(){
    counterNumber -= 1;
    counter.innerHTML = counterNumber;

    let counterSerialized = JSON.stringify(counterNumber);

    localStorage.setItem("MyCounter", counterSerialized);

    let counterDeserialized = JSON.parse(localStorage.getItem("MyCounter"));

    console.log(counterDeserialized)
}