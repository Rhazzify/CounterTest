package controllers;

public class CounterController {

    int counter = 0;

    public static void onClick(int counter){
        
        counter += 1;
        System.out.println(counter);
    }
    public static void main(String[] args) {
        onClick(1);
        onClick(2);
        onClick(3);
        onClick(4);
    }
}
